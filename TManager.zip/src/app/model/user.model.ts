export interface User {
    id : string,
    lastname : string,
    firstname : string,
    login: string,
    password: string,
    email: string,
    role: string,
}