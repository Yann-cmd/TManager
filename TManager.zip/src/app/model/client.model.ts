export interface Client {
    id : string,
    lastname : string,
    firstname : string,
    phoneNumber: string,
    email: string,
    projectId: string,
}