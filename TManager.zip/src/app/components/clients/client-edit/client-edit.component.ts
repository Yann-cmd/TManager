import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Client } from '../../../model/client.model';
import { ClientService } from '../../../services/client.service';
import { Project } from '../../../model/project.model';
import { ProjectService } from '../../../services/project.service';

@Component({
  selector: 'app-client-edit',
  templateUrl: './client-edit.component.html',
  styleUrl: './client-edit.component.css'
})
export class ClientEditComponent implements OnInit{
  public clientEditForm!: FormGroup;
  public errorMessage: string = '';
  public defaultSelectedProjectId: string = '';
  public projects : Project[] = [];

  constructor(
    @Inject(MAT_DIALOG_DATA) public client: Client, 
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<ClientEditComponent>, 
    private clientService: ClientService,
    private projectService: ProjectService,
  ) {}

  ngOnInit(): void {
    const client = this.client;
    this.defaultSelectedProjectId = client.projectId;
    this.projectService.getProjects().subscribe((projects) => this.projects = projects);
    this.clientEditForm=this.fb.group({
      firstname : this.fb.control('', [Validators.required]),
      lastname : this.fb.control('', [Validators.required]),
      phoneNumber : this.fb.control(''),
      email : this.fb.control('', [Validators.required]),
      projectId : this.fb.control(''),
    });

    //charger les données du formulaires
    this.clientEditForm.patchValue({
      firstname: client.firstname,
      lastname: client.lastname,
      phoneNumber: client.phoneNumber,
      email: client.email,
      projectId: client.projectId
    });
  }

  closeEdit(): void {
    this.dialogRef.close();
  }

  updateProjects(projectList: Project[], selectedProjectId: string, updatedClient: Client): void {
    // update l'attribut clients des projets
    projectList.forEach((project) => {
      // si le projet est bien celui sélectionné lors de l'update
      if(project.id === selectedProjectId){
        // on ajoute au projet le client seulement si il n'était pas déjà associé au projet
        project.clients.find((client) => client.id === this.client.id) ? '' : project.clients.push(updatedClient)
      }
      // sinon on retire le client des projets non sélectionnés
      else{
        project.clients = project.clients.filter((client) => client.id !== this.client.id)
      }
      this.projectService.updateProject(project).subscribe({error: (err) => { this.errorMessage = err.message }})
    })
  }

  handleUpdate(): void {
    if (this.clientEditForm.valid) {
      const selectedProjectId = this.clientEditForm.value.projectId
      // contient le projet sélectionné ainsi que le projet qui était sélectionné avant l'update
      const combinedList: string[] = Array.from(new Set([selectedProjectId, this.defaultSelectedProjectId]));
      // on parcours tous les projets
      this.projectService.getProjectsByIds(combinedList).subscribe({
        next: (projectList) => {

          // créer l'objet du client modifié
          const updatedClient: Client = {
            id: this.client.id,
            ...this.clientEditForm.value
          };

          // si le champs des projets à été changé
          if(this.defaultSelectedProjectId !== selectedProjectId){
            this.updateProjects(projectList, selectedProjectId, updatedClient)
          }

          // update le client
          this.clientService.updateClient(updatedClient).subscribe({
            error: (err) => { this.errorMessage = err.message },
            complete: () => { this.dialogRef.close(); }
          })
        }
      });
    }
  }
}
