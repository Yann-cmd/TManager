import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../../services/authentication.service';
import { UserService } from '../../services/user.service';
import { User } from '../../model/user.model';
import { Client } from '../../model/client.model';
import { ClientService } from '../../services/client.service';
import { ProjectService } from '../../services/project.service';
import { TicketService } from '../../services/ticket.service';
import { Ticket } from '../../model/tickets.model';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent implements OnInit{
  public connectedUser : User | Client | undefined = undefined;
  public openedProjectCount : number = 0;
  public closedProjectCount : number = 0;
  // on va dire que "récent" signifie moins d'une semaine
  public recentProjectCount : number = 0;
  // on va dire que la performance représente le pourcentage de projet fini par rapport au nombre total de projet ouvert
  public performanceProject : string = "";

  //graphes
  public barChartData: { name: string; value: number; }[] = [];
  public pieChartData: { name: string; value: number; }[] = [];

  public monthNames = [
    'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 
    'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'
  ];

  constructor(
    public authService : AuthenticationService, 
    private userService: UserService, 
    private clientService: ClientService,
    private projectService: ProjectService,
    private ticketService: TicketService,
  ) {}

  ngOnInit() {
    // pour claculer les stats des projets dans les cards
    this.computeProjetsStats()
    // pour calculer les datas des graphes
    this.computeChartsStats()

    if(this.authService.isUser()){
      this.userService.getUserById(this.authService.id!).subscribe(user => this.connectedUser = user[0])
    }
    if(this.authService.isClient()){
      this.clientService.getClientById(this.authService.id!).subscribe(client => this.connectedUser = client[0])
    }
  }

  computeProjetsStats() {
    const oneWeekInMillis = 7 * 24 * 60 * 60 * 1000;
    const now = new Date().getTime();
    this.projectService.fillDefaultValues();
    this.projectService.projects$.subscribe({
      next: (projectList) => {
        this.openedProjectCount = projectList.filter(project => project.isClosed === false).length;
        this.closedProjectCount = projectList.filter(project => project.isClosed === true).length;
        this.recentProjectCount = projectList.filter(project => {
          // on récupère la valeur en milliseconde de la date de chaque projet
          const objDate = new Date(project.date).getTime();
          // et on compare cette date avec now() pour check si la différence des 2 est inférieure à une semaine (en milliseconde) ou non
          return Math.abs(now - objDate) <= oneWeekInMillis;
        }).length;
        this.performanceProject = projectList.length > 0 ? Math.round((this.closedProjectCount / projectList.length) * 100) + '%' : 'Aucun projet';
      }
    })
  }

  computeChartsStats() {
    this.ticketService.fillDefaultValues();
    this.ticketService.ticket$.subscribe({
      next: (ticketList) => {
        this.computeBarChartData(ticketList);
        this.computePieChartData(ticketList);
      }
    });
  }

  computeBarChartData(ticketList: Ticket[]) {
    const result = [];
    const today = new Date();
    const currentMonth = today.getMonth();
    let yearToCheck = today.getFullYear();
  
    for (let i = 0; i < 4; i++) {
      const monthIndex = (currentMonth - i + 12) % 12;
  
      // Vérifie si le mois appartient à l'année précédente
      if (monthIndex > currentMonth) {
        yearToCheck--;
      }
  
      // Filtre les tickets par année et mois
      const ticketNumber = ticketList.filter((ticket) => {
        const ticketDate = new Date(ticket.date);
        return ticketDate.getFullYear() === yearToCheck && ticketDate.getMonth() === monthIndex;
      }).length;
  
      result.unshift({
        name: this.monthNames[monthIndex],
        value: ticketNumber == 0 ? 0.0001 : ticketNumber,
      });
      // Reset de l'année pour le prochain mois
      yearToCheck = today.getFullYear();
    }
    console.log(result)
    this.barChartData = result;
  }

  computePieChartData(ticketList: Ticket[]){
    const result: { name: string; value: number; }[] = [];
    const clientsIdsWhoSubmitTicket = ticketList.filter((ticket) => ticket.clientID !== null).map((ticket) => ticket.clientID as string);
    this.clientService.getClientsByIds(clientsIdsWhoSubmitTicket).subscribe({
      next: (clientList) => {
        clientList.forEach((client) => result.push({name: client.firstname, value: clientsIdsWhoSubmitTicket.filter((id) => id == client.id).length}));
      }
    })
    this.pieChartData = result;
  }
}
