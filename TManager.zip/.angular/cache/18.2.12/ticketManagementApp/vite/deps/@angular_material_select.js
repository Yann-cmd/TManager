import {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  matSelectAnimations
} from "./chunk-CWB7VFPF.js";
import "./chunk-3ZRT2O6H.js";
import "./chunk-GHGRPWOH.js";
import "./chunk-D6QNJXVX.js";
import "./chunk-H6DDMR6X.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-2XGIX3XR.js";
import "./chunk-TH2JOATV.js";
import {
  MatOptgroup,
  MatOption
} from "./chunk-MY2BI2SJ.js";
import "./chunk-FMUAAVGR.js";
import "./chunk-2AHVS25V.js";
import "./chunk-BHAS47UM.js";
import "./chunk-UFPNH3LU.js";
import "./chunk-KG6VIPBZ.js";
export {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatOptgroup,
  MatOption,
  MatPrefix,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  MatSuffix,
  matSelectAnimations
};
//# sourceMappingURL=@angular_material_select.js.map
